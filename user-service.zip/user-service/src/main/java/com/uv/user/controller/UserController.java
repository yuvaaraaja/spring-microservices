package com.uv.user.controller;

import com.uv.user.VO.UserResponseValueObject;
import com.uv.user.entity.User;
import com.uv.user.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
@Slf4j
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/")
    public User saveUser(@RequestBody User user) {
        log.info("Inside saveUser of UserController");
        return userService.saveUser(user);
    }

    @GetMapping("/{id}")
    public UserResponseValueObject getByUserId(@PathVariable Long id) {
        log.info("Inside getByUserId of UserController");
        return userService.getByUserId(id);
    }

}
