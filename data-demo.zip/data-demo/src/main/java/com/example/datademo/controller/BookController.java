package com.example.datademo.controller;

import com.example.datademo.model.Book;
import com.example.datademo.service.BookService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/")
@Slf4j
public class BookController {

    @Autowired
    private BookService bookService;

    @PostMapping("/book")
    public Book createBook(@RequestBody Book bookObj) {
        log.info("Inside createBook of BookController class");
        return bookService.saveBook(bookObj);
    }

    @PutMapping("/book")
    public String updateBook(@RequestBody Book bookObj) {
        log.info("Inside updateBook of BookController class");
        return bookService.updateBook(bookObj);
    }

    @GetMapping("/book/get")
    public Book getByBookName(@RequestParam String bookName) {
        log.info("Inside getByBookName of BookController class");
        return bookService.getByBookName(bookName);
    }

    @GetMapping("/books")
    public List<Book> getAllBooks() {
        log.info("Inside getAllBooks of BookController class");
        return bookService.getAllBooks();
    }

    @DeleteMapping("/book/delete")
    public String deleteBook(@RequestParam String bookName) {
        log.info("Inside deleteBook of BookController class");
        return bookService.deleteBook(bookName);
    }

    @GetMapping("/book/publishedyear")
    public List<Book> getBookByAfterPublicationYear(@RequestParam Integer year) {
        log.info("Inside getBookByAfterPublicationYear of BookController class");
        return bookService.getBookByAfterPublicationYear(year);
    }

    @GetMapping("/book/publication")
    public List<Book> getBookByPublication(@RequestParam String publication) {
        log.info("Inside getBookByPublication of BookController class");
        return bookService.getBookByPublication(publication);
    }

}
