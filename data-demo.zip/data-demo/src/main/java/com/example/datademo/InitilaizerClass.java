package com.example.datademo;

import com.example.datademo.model.Book;
import com.example.datademo.service.BookService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class InitilaizerClass {

    @Autowired
    BookService bookService;

    @EventListener(ApplicationReadyEvent.class)
    public void fillTestData()
    {
        log.info("Application started successfully!");
        Book book1 = new Book(1L,"Book1", "Author1", "Publication1", 2015, 67000);
        Book book2 = new Book(2L,"Book2", "Author2", "Publication1", 2010, 100000);
        Book book3 = new Book(3L,"Book3", "Author3", "Publication3", 1999, 98000);
        Book book4 = new Book(4L,"Book4", "Author3", "Publication2", 2005, 10000);
        bookService.saveBook(book1);
        bookService.saveBook(book2);
        bookService.saveBook(book3);
        bookService.saveBook(book4);
        log.info(bookService.getAllBooks().size() + " books inserted");
    }

}


