package com.example.datademo.service;

import com.example.datademo.model.Book;
import com.example.datademo.repository.BookRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    public Book saveBook(Book bookObj) {
        log.info("Inside saveBook of BookService class");
        return bookRepository.save(bookObj);
    }

    public String updateBook(Book bookObj) {
        log.info("Inside updateBook of BookService class");
        if(bookRepository.existsByBookName(bookObj.getBookName())) {
            Book bookFromDb = bookRepository.getById(bookObj.getBookId());
            bookFromDb.setBookName(bookObj.getBookName());
            bookFromDb.setAuthor(bookObj.getAuthor());
            bookFromDb.setPublication(bookObj.getPublication());
            bookFromDb.setPublishedYear(bookObj.getPublishedYear());
            bookFromDb.setCopiesSold(bookObj.getCopiesSold());
            bookRepository.save(bookFromDb);
            return "success";
        }
        else {
            return "No book with title - " + bookObj.getBookName();
        }
    }

    public Book getByBookName(String bookName) {
        log.info("Inside getByBookName of BookService class");
        return bookRepository.findByBookName(bookName);
    }

    public List<Book> getAllBooks() {
        log.info("Inside getAllBooks of BookService class");
        return bookRepository.findAll();
    }

    public String deleteBook(String bookName) {
        log.info("Inside deleteBook of BookService class");
        if(bookRepository.existsByBookName(bookName)) {
            Book bookObj = bookRepository.findByBookName(bookName);
            bookRepository.delete(bookObj);
            return "success";
        }
        else {
            return "No book with title - " + bookName;
        }
    }

    public List<Book> getBookByAfterPublicationYear(Integer year){
        log.info("Inside getBookByAfterPublicationYear of BookService class");
        return bookRepository.findBookByAfterPublicationYear(year);
    }

    public List<Book> getBookByPublication(String publication){
        log.info("Inside getBookByPublication of BookService class");
        return bookRepository.findBookByPublication(publication);
    }

}
