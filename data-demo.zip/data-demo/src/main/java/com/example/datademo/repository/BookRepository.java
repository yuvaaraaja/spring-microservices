package com.example.datademo.repository;

import com.example.datademo.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {
    Book findByBookName(String bookName);
    boolean existsByBookName(String bookName);

    @Query(value = "SELECT b FROM Book b WHERE b.publishedYear >= ?1")
    List<Book> findBookByAfterPublicationYear(Integer year);

    List<Book> findBookByPublication(String Publication);
}
