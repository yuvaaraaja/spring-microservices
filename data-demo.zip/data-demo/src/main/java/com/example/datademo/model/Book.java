package com.example.datademo.model;

import lombok.*;

import javax.persistence.*;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@NamedQuery(name = "findBookByPublication", query = "SELECT b FROM Book b WHERE b.publication = ?1")
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long bookId;
    private String bookName;
    private String author;
    private String publication;
    private Integer publishedYear;
    private Integer copiesSold;

}
