package com.example.datademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
